#!/usr/bin/env python3
"""
Analyzer: Trích xuất và xác minh thông điệp từ stego WAV.
Chạy: python3 extract_verify.py
"""
import wave, struct, os

LAB_DIR = '/home/ubuntu/lsb_lab'


def get_lsb_bits(amplitude):
    a = abs(amplitude)
    if a < 8000:
        return 1
    elif a < 20000:
        return 2
    else:
        return 3


def extract_adaptive(wav_stego, wav_cover):
    with wave.open(wav_stego, 'r') as f:
        frames_s = f.readframes(f.getnframes())
    with wave.open(wav_cover, 'r') as f:
        frames_c = f.readframes(f.getnframes())
    stego = struct.unpack(f'<{len(frames_s)//2}h', frames_s)
    cover = struct.unpack(f'<{len(frames_c)//2}h', frames_c)
    bits = ''
    msg  = ''
    for s_val, c_val in zip(stego, cover):
        n_bits = get_lsb_bits(c_val)
        mask   = (1 << n_bits) - 1
        chunk  = f'{s_val & mask:0{n_bits}b}'
        bits  += chunk
        while len(bits) >= 8:
            msg  += chr(int(bits[:8], 2))
            bits  = bits[8:]
            if msg.endswith('||END||'):
                return msg[:-7]
    return None


stego = os.path.join(LAB_DIR, 'stego_adaptive.wav')
cover = os.path.join(LAB_DIR, 'cover_audio.wav')

print("[ANALYZER] Kiem tra trich xuat thong diep...")
decoded = extract_adaptive(stego, cover)

result_path = os.path.join(LAB_DIR, 'extract_verify.txt')
with open(result_path, 'w') as f:
    if decoded:
        print(f"[OK] Thong diep: '{decoded}'")
        f.write(f"decoded={decoded}\n")
        f.write(f"verify=PASS\n")
    else:
        print("[FAIL] Khong tim thay thong diep")
        f.write("decoded=NOT_FOUND\nverify=FAIL\n")
print(f"[OK] {result_path}")
