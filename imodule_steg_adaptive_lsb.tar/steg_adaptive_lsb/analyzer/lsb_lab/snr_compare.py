#!/usr/bin/env python3
"""
Analyzer: So sánh SNR giữa các phương pháp (chạy trên container analyzer).
File stego được chuyển từ embedder sang qua SCP hoặc đã có sẵn.
Chạy: python3 snr_compare.py
"""
import wave, struct, math, os, shutil
import numpy as np

LAB_DIR = '/home/ubuntu/lsb_lab'
RESULT_DIR = '/home/ubuntu/.local/result'


def get_lsb_bits(amplitude):
    a = abs(amplitude)
    if a < 8000:
        return 1
    elif a < 20000:
        return 2
    else:
        return 3


def snr_db(orig_path, stego_path):
    def rd(p):
        with wave.open(p, 'r') as f:
            d = f.readframes(f.getnframes())
        return np.array(struct.unpack(f'<{len(d)//2}h', d), dtype=np.float64)
    s, t = rd(orig_path), rd(stego_path)
    n = min(len(s), len(t))
    sig   = np.sum(s[:n] ** 2)
    noise = np.sum((s[:n] - t[:n]) ** 2)
    return 10 * math.log10(sig / noise) if noise > 0 else float('inf')


def capacity_bits(wav_path, policy):
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())
    samples = struct.unpack(f'<{len(frames)//2}h', frames)
    if policy == 'fixed1':
        return len(samples) * 1
    if policy == 'fixed2':
        return len(samples) * 2
    if policy == 'adaptive':
        return sum(get_lsb_bits(s) for s in samples)
    return 0


cover = os.path.join(LAB_DIR, 'cover_audio.wav')
methods = [
    ('fixed1',   'stego_fixed1.wav'),
    ('fixed2',   'stego_fixed2.wav'),
    ('adaptive', 'stego_adaptive.wav'),
]

print("=== [ANALYZER] So Sanh SNR & Dung Luong ===")
snr_data = {}
cap_data = {}
missing_files = []
for pol, fname in methods:
    p = os.path.join(LAB_DIR, fname)
    if not os.path.exists(p):
        print(f"[SKIP] {fname} khong ton tai - hay copy tu embedder truoc")
        missing_files.append(fname)
        snr_data[pol] = 0.0
        cap_data[pol] = 0
        continue
    snr = snr_db(cover, p)
    cap = capacity_bits(cover, pol)
    snr_data[pol] = snr
    cap_data[pol] = cap
    print(f"  {pol:>10}: cap={cap//8} bytes | SNR={snr:.2f} dB")

# Ghi SNR result
snr_path = os.path.join(LAB_DIR, 'snr_result.txt')
with open(snr_path, 'w') as f:
    for pol, snr in snr_data.items():
        f.write(f"{pol}_snr={snr:.4f}\n")
    f.write(f"adaptive_snr={snr_data.get('adaptive', 0):.4f}\n")
    f.write(f"analyzer_complete={'YES' if not missing_files else 'NO'}\n")
    f.write("ANALYZER_COMPLETE_YES\n" if not missing_files else "ANALYZER_COMPLETE_NO\n")
    if missing_files:
        f.write(f"missing_files={','.join(missing_files)}\n")
os.makedirs(RESULT_DIR, exist_ok=True)
shutil.copyfile(snr_path, os.path.join(RESULT_DIR, 'snr_result.txt'))
print(f"[OK] {snr_path}")

# Ghi capacity result
cap_path = os.path.join(LAB_DIR, 'capacity_result.txt')
with open(cap_path, 'w') as f:
    for pol, cap in cap_data.items():
        f.write(f"{pol}_capacity_bytes={cap//8}\n")
    f.write(f"adaptive_capacity={cap_data.get('adaptive', 0)//8}\n")
    f.write(f"capacity_complete={'YES' if not missing_files else 'NO'}\n")
    f.write("CAPACITY_COMPLETE_YES\n" if not missing_files else "CAPACITY_COMPLETE_NO\n")
shutil.copyfile(cap_path, os.path.join(RESULT_DIR, 'capacity_result.txt'))
print(f"[OK] {cap_path}")
