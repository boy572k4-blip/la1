#!/bin/bash
sudo service ssh start 2>/dev/null

sudo mkdir -p /var/labtainer
echo "steg_adaptive_lsb_seed" | sudo tee /var/labtainer/seed >/dev/null

mkdir -p /home/ubuntu/.local
echo "steg_adaptive_lsb_seed"   > /home/ubuntu/.local/.seed
echo "student@labtainer.local"  > /home/ubuntu/.local/.email
echo "steg_adaptive_lsb"        > /home/ubuntu/.local/.labname
sudo chown -R ubuntu:ubuntu /home/ubuntu/.local

sudo touch /var/labtainer/did_param

mkdir -p /home/ubuntu/lsb_lab
sudo chown -R ubuntu:ubuntu /home/ubuntu/lsb_lab
sudo ln -sfn /home/ubuntu/lsb_lab /root/lsb_lab 2>/dev/null || true
grep -qxF 'cd /home/ubuntu/lsb_lab 2>/dev/null || true' /home/ubuntu/.bashrc 2>/dev/null || \
    echo 'cd /home/ubuntu/lsb_lab 2>/dev/null || true' >> /home/ubuntu/.bashrc

tail -f /dev/null
