#!/bin/bash
# ============================================================
# Build và Push Docker images cho steg_adaptive_lsb Labtainer
# DockerHub: r3xonx
# GitHub   : https://github.com/boy572k4-blip/la1.git
# ============================================================
set -e

REGISTRY="r3xonx"
LAB_NAME="steg_adaptive_lsb"
CONTAINERS=("embedder" "analyzer")

echo "====================================================="
echo " BUILD & PUSH: $LAB_NAME"
echo "====================================================="

# Đăng nhập DockerHub
echo "[*] Dang nhap DockerHub..."
docker login -u "$REGISTRY"

for CONTAINER in "${CONTAINERS[@]}"; do
    IMAGE="${REGISTRY}/${LAB_NAME}.${CONTAINER}"
    echo ""
    echo "[*] Building: $IMAGE"
    docker build -t "$IMAGE" "./$CONTAINER/"
    echo "[*] Pushing : $IMAGE"
    docker push "$IMAGE"
    echo "[OK] $IMAGE"
done

echo ""
echo "====================================================="
echo " Push len GitHub..."
echo "====================================================="

# Push source lên GitHub
REPO_URL="https://github.com/boy572k4-blip/la1.git"

if [ ! -d ".git" ]; then
    git init
    git remote add origin "$REPO_URL"
fi

# Tạo imodule tar
echo "[*] Tao imodule tar..."
cd ..
tar cf "imodule_${LAB_NAME}.tar" "$LAB_NAME/"
mv "imodule_${LAB_NAME}.tar" "$LAB_NAME/"
cd "$LAB_NAME"

git add -A
git commit -m "Update steg_adaptive_lsb labtainer [$(date '+%Y-%m-%d %H:%M')]"
git branch -M main
git push -u origin main --force

echo ""
echo "====================================================="
echo " HOAN THANH!"
echo " imodule URL:"
echo "   https://github.com/boy572k4-blip/la1/raw/main/imodule_${LAB_NAME}.tar"
echo "====================================================="
