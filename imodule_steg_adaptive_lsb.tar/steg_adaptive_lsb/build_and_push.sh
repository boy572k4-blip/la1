#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_adaptive_lsb"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.embedder.student"
echo " $REGISTRY/${LAB}.analyzer.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

echo "[BUILD] embedder..."
cd "$SCRIPT_DIR/embedder" && docker build --no-cache -t "$REGISTRY/${LAB}.embedder.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build embedder thất bại!" && exit 1

echo "[BUILD] analyzer..."
cd "$SCRIPT_DIR/analyzer" && docker build --no-cache -t "$REGISTRY/${LAB}.analyzer.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build analyzer thất bại!" && exit 1

echo "[VERIFY] image workdir..."
EMBEDDER_WORKDIR="$(docker inspect "$REGISTRY/${LAB}.embedder.student:latest" --format '{{.Config.WorkingDir}}')"
ANALYZER_WORKDIR="$(docker inspect "$REGISTRY/${LAB}.analyzer.student:latest" --format '{{.Config.WorkingDir}}')"
echo "  embedder workdir: $EMBEDDER_WORKDIR"
echo "  analyzer workdir: $ANALYZER_WORKDIR"

if [ "$EMBEDDER_WORKDIR" != "/home/ubuntu/lsb_lab" ]; then
    echo "[ERROR] embedder image workdir is wrong"
    exit 1
fi

if [ "$ANALYZER_WORKDIR" != "/home/ubuntu/lsb_lab" ]; then
    echo "[ERROR] analyzer image workdir is wrong"
    exit 1
fi

echo "[PUSH] embedder..."
docker push "$REGISTRY/${LAB}.embedder.student:latest"
echo "[PUSH] analyzer..."
docker push "$REGISTRY/${LAB}.analyzer.student:latest"

echo "=============================================="
echo " HOÀN THÀNH!"
echo " Images:"
echo "   - $REGISTRY/${LAB}.embedder.student:latest"
echo "   - $REGISTRY/${LAB}.analyzer.student:latest"
echo "=============================================="
