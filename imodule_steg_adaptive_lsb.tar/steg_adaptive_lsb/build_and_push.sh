#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_adaptive_lsb"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.embedder.student"
echo " $REGISTRY/${LAB}.analyzer.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

echo "[BUILD] embedder..."
cd "$SCRIPT_DIR/embedder" && docker build --no-cache -t "$REGISTRY/${LAB}.embedder.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build embedder thất bại!" && exit 1

echo "[BUILD] analyzer..."
cd "$SCRIPT_DIR/analyzer" && docker build --no-cache -t "$REGISTRY/${LAB}.analyzer.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build analyzer thất bại!" && exit 1

echo "[VERIFY] image defaults..."
EMBEDDER_DEFAULTS="$(docker inspect "$REGISTRY/${LAB}.embedder.student:latest" --format '{{.Config.User}} {{.Config.WorkingDir}}')"
ANALYZER_DEFAULTS="$(docker inspect "$REGISTRY/${LAB}.analyzer.student:latest" --format '{{.Config.User}} {{.Config.WorkingDir}}')"
echo "  embedder: $EMBEDDER_DEFAULTS"
echo "  analyzer: $ANALYZER_DEFAULTS"

if [ "$EMBEDDER_DEFAULTS" != "ubuntu /home/ubuntu/lsb_lab" ]; then
    echo "[ERROR] embedder image default user/workdir is wrong"
    exit 1
fi

if [ "$ANALYZER_DEFAULTS" != "ubuntu /home/ubuntu/lsb_lab" ]; then
    echo "[ERROR] analyzer image default user/workdir is wrong"
    exit 1
fi

echo "[PUSH] embedder..."
docker push "$REGISTRY/${LAB}.embedder.student:latest"
echo "[PUSH] analyzer..."
docker push "$REGISTRY/${LAB}.analyzer.student:latest"

echo "=============================================="
echo " HOÀN THÀNH!"
echo " Images:"
echo "   - $REGISTRY/${LAB}.embedder.student:latest"
echo "   - $REGISTRY/${LAB}.analyzer.student:latest"
echo "=============================================="
