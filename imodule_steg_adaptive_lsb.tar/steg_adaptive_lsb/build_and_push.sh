#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_adaptive_lsb"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.embedder.student"
echo " $REGISTRY/${LAB}.analyzer.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

echo "[BUILD] embedder..."
cd "$SCRIPT_DIR/embedder" && docker build -t "$REGISTRY/${LAB}.embedder.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build embedder thất bại!" && exit 1

echo "[BUILD] analyzer..."
cd "$SCRIPT_DIR/analyzer" && docker build -t "$REGISTRY/${LAB}.analyzer.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build analyzer thất bại!" && exit 1

echo "[PUSH] embedder..."
docker push "$REGISTRY/${LAB}.embedder.student:latest"
echo "[PUSH] analyzer..."
docker push "$REGISTRY/${LAB}.analyzer.student:latest"

echo "=============================================="
echo " HOÀN THÀNH!"
echo " Images:"
echo "   - $REGISTRY/${LAB}.embedder.student:latest"
echo "   - $REGISTRY/${LAB}.analyzer.student:latest"
echo "=============================================="
