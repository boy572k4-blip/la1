#!/bin/bash
# =============================================================
# Build & Push Docker images for steg_adaptive_lsb Labtainer
# Usage: bash build_and_push.sh
# =============================================================

REGISTRY="r3xonx"
LAB="steg_adaptive_lsb"
CONTAINERS=("embedder" "analyzer")

echo "=============================================="
echo " Building & Pushing: $LAB"
echo " Registry: $REGISTRY"
echo "=============================================="

for CONTAINER in "${CONTAINERS[@]}"; do
    IMAGE="${REGISTRY}/${LAB}.${CONTAINER}"
    echo ""
    echo "[*] Building: $IMAGE"
    docker build -t "$IMAGE" "./${CONTAINER}/"
    if [ $? -ne 0 ]; then
        echo "[ERROR] Build failed for $CONTAINER"
        exit 1
    fi
    echo "[*] Pushing: $IMAGE"
    docker push "$IMAGE"
    if [ $? -ne 0 ]; then
        echo "[ERROR] Push failed for $CONTAINER"
        exit 1
    fi
    echo "[OK] Done: $IMAGE"
done

echo ""
echo "=============================================="
echo " All images built and pushed successfully!"
echo " Images:"
for CONTAINER in "${CONTAINERS[@]}"; do
    echo "   - ${REGISTRY}/${LAB}.${CONTAINER}"
done
echo "=============================================="
