#!/usr/bin/env python3
"""
Bước 2: Xây dựng và kiểm tra hàm tra cứu số bit LSB theo biên độ.
Chạy: python3 adaptive_policy.py
"""
import os

LAB_DIR = '/home/ubuntu/lsb_lab'

def get_lsb_bits(amplitude):
    """
    Chính sách Adaptive LSB:
      |biên độ| < 8000  -> 1 bit  (vùng yên tĩnh)
      |biên độ| < 20000 -> 2 bits (vùng trung bình)
      |biên độ| >= 20000-> 3 bits (vùng ồn ào)
    """
    a = abs(amplitude)
    if a < 8000:
        return 1
    elif a < 20000:
        return 2
    else:
        return 3


# Kiểm tra nhanh
test_cases = [500, 9000, 25000, -30000, 0, 8000, 19999, 20000]
results = {}
print("=== Kiểm tra chính sách Adaptive LSB ===")
for val in test_cases:
    bits = get_lsb_bits(val)
    results[val] = bits
    print(f"  Mẫu {val:>7} -> dùng {bits} bit LSB")

# Lưu kết quả để checkwork
result_path = os.path.join(LAB_DIR, 'policy_result.txt')
with open(result_path, 'w') as f:
    f.write("=== Ket qua kiem tra ham get_lsb_bits ===\n")
    for val, bits in results.items():
        f.write(f"bits_for_{val}={bits}\n")
    # Kiểm tra đúng/sai
    ok = (results[500]==1 and results[9000]==2 and results[25000]==3 and results[-30000]==3)
    f.write(f"policy_correct={'YES' if ok else 'NO'}\n")

print(f"\n[OK] Kết quả đã lưu vào: {result_path}")
if __name__ == '__main__':
    pass
