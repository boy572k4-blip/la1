#!/usr/bin/env python3
"""
Step 2: complete and test the Adaptive LSB policy.

Student task:
  Fill get_lsb_bits() so that:
    abs(amplitude) < 8000   -> 1 bit
    abs(amplitude) < 20000  -> 2 bits
    abs(amplitude) >= 20000 -> 3 bits
"""
import os
import shutil

LAB_DIR = "/home/ubuntu/lsb_lab"
RESULT_DIR = "/home/ubuntu/.local/result"


def save_result(name, content):
    os.makedirs(RESULT_DIR, exist_ok=True)
    lab_path = os.path.join(LAB_DIR, name)
    result_path = os.path.join(RESULT_DIR, name)
    with open(lab_path, "w") as f:
        f.write(content)
    shutil.copyfile(lab_path, result_path)
    return lab_path


def get_lsb_bits(amplitude):
    # TODO: Student completes this function.
    # Hint: use abs(amplitude), then compare with 8000 and 20000.
    raise NotImplementedError("Complete get_lsb_bits() first")


def main():
    test_cases = [500, 9000, 25000, -30000, 0, 8000, 19999, 20000]
    expected = {
        500: 1,
        9000: 2,
        25000: 3,
        -30000: 3,
        0: 1,
        8000: 2,
        19999: 2,
        20000: 3,
    }

    lines = ["=== Adaptive LSB policy test ==="]
    results = {}

    try:
        for val in test_cases:
            bits = get_lsb_bits(val)
            results[val] = bits
            status = "OK" if bits == expected[val] else "WRONG"
            lines.append(f"bits_for_{val}={bits}")
            lines.append(f"case_{val}={status}")
            print(f"sample {val:>7} -> {bits} bit(s) [{status}]")

        ok = all(results[v] == expected[v] for v in expected)
    except Exception as exc:
        ok = False
        lines.append(f"policy_error={type(exc).__name__}: {exc}")
        print(f"[ERROR] {exc}")

    lines.append(f"policy_correct={'YES' if ok else 'NO'}")
    lines.append("POLICY_CORRECT_YES" if ok else "POLICY_CORRECT_NO")
    path = save_result("policy_result.txt", "\n".join(lines) + "\n")
    print(f"[OK] result saved to: {path}")


if __name__ == "__main__":
    main()
