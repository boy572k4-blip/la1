#!/usr/bin/env python3
"""
Bước 1: Phân tích phân phối biên độ của file âm thanh gốc.
Chạy: python3 analyze_amplitude.py
"""
import wave, struct, os, shutil
import numpy as np

LAB_DIR = '/home/ubuntu/lsb_lab'
RESULT_DIR = '/home/ubuntu/.local/result'
WAV_PATH = os.path.join(LAB_DIR, 'cover_audio.wav')

with wave.open(WAV_PATH, 'r') as f:
    frames = f.readframes(f.getnframes())

samples = np.array(struct.unpack(f'<{len(frames)//2}h', frames))
amp = np.abs(samples)

amp_min  = int(amp.min())
amp_max  = int(amp.max())
amp_mean = float(amp.mean())
amp_std  = float(amp.std())

print(f"Biên độ min  : {amp_min}")
print(f"Biên độ max  : {amp_max}")
print(f"Biên độ mean : {amp_mean:.1f}")
print(f"Biên độ std  : {amp_std:.1f}")

# Phân vùng theo ngưỡng
zone1 = int(np.sum(amp < 8000))
zone2 = int(np.sum((amp >= 8000) & (amp < 20000)))
zone3 = int(np.sum(amp >= 20000))
total = len(samples)
print(f"\nPhân vùng biên độ:")
print(f"  |amp| < 8000  (1 bit LSB): {zone1:>8} mẫu ({100*zone1/total:.1f}%)")
print(f"  8000~20000   (2 bit LSB): {zone2:>8} mẫu ({100*zone2/total:.1f}%)")
print(f"  >= 20000     (3 bit LSB): {zone3:>8} mẫu ({100*zone3/total:.1f}%)")

# Lưu kết quả để checkwork
result_path = os.path.join(LAB_DIR, 'amplitude_result.txt')
with open(result_path, 'w') as f:
    f.write(f"amp_min={amp_min}\n")
    f.write(f"amp_max={amp_max}\n")
    f.write(f"amp_mean={amp_mean:.1f}\n")
    f.write(f"amp_std={amp_std:.1f}\n")
    f.write(f"zone1_count={zone1}\n")
    f.write(f"zone2_count={zone2}\n")
    f.write(f"zone3_count={zone3}\n")
os.makedirs(RESULT_DIR, exist_ok=True)
shutil.copyfile(result_path, os.path.join(RESULT_DIR, 'amplitude_result.txt'))
print(f"\n[OK] Kết quả đã lưu vào: {result_path}")

# Vẽ histogram (nếu có matplotlib)
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.figure(figsize=(10, 5))
    plt.hist(amp, bins=100, color='steelblue', edgecolor='none')
    plt.xlabel("Biên độ tuyệt đối")
    plt.ylabel("Số mẫu")
    plt.title("Phân phối biên độ mẫu âm thanh")
    plt.axvline(8000,  color='red',    ls='--', label='Ngưỡng thấp (8000)  → 1 bit LSB')
    plt.axvline(20000, color='orange', ls='--', label='Ngưỡng cao (20000) → 3 bit LSB')
    plt.legend()
    plt.tight_layout()
    png_path = os.path.join(LAB_DIR, 'amplitude_dist.png')
    plt.savefig(png_path, dpi=150)
    print(f"[OK] Biểu đồ đã lưu vào: {png_path}")
except ImportError:
    print("[WARN] matplotlib không có sẵn, bỏ qua vẽ biểu đồ.")
