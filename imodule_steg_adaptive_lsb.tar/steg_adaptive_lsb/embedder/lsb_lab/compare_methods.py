#!/usr/bin/env python3
"""
Bước 5: So sánh dung lượng và chất lượng âm thanh (SNR) giữa
  - LSB cố định 1 bit
  - LSB cố định 2 bit
  - Adaptive LSB
Chạy: python3 compare_methods.py
"""
import wave, struct, math, os
import numpy as np

LAB_DIR = '/home/ubuntu/lsb_lab'


def get_lsb_bits(amplitude):
    a = abs(amplitude)
    if a < 8000:
        return 1
    elif a < 20000:
        return 2
    else:
        return 3


def snr_db(orig_path, stego_path):
    def rd(p):
        with wave.open(p, 'r') as f:
            d = f.readframes(f.getnframes())
        return np.array(struct.unpack(f'<{len(d)//2}h', d), dtype=np.float64)
    s, t = rd(orig_path), rd(stego_path)
    n = min(len(s), len(t))
    sig   = np.sum(s[:n] ** 2)
    noise = np.sum((s[:n] - t[:n]) ** 2)
    return 10 * math.log10(sig / noise) if noise > 0 else float('inf')


def capacity_bits(wav_path, policy):
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())
    samples = struct.unpack(f'<{len(frames)//2}h', frames)
    if policy == 'fixed1':
        return len(samples) * 1
    if policy == 'fixed2':
        return len(samples) * 2
    if policy == 'adaptive':
        return sum(get_lsb_bits(s) for s in samples)
    return 0


cover_path = os.path.join(LAB_DIR, 'cover_audio.wav')
methods = [
    ('fixed1',   'stego_fixed1.wav'),
    ('fixed2',   'stego_fixed2.wav'),
    ('adaptive', 'stego_adaptive.wav'),
]

print("=== So Sanh Phuong Phap LSB ===")
print(f"{'Phuong phap':>12} | {'Dung luong (bytes)':>18} | {'SNR (dB)':>10}")
print("-" * 50)

snr_results = {}
cap_results = {}
for pol, stego_name in methods:
    stego_path = os.path.join(LAB_DIR, stego_name)
    cap = capacity_bits(cover_path, pol)
    snr = snr_db(cover_path, stego_path)
    snr_results[pol] = snr
    cap_results[pol] = cap
    print(f"  {pol:>10}: {cap//8:>8} bytes | SNR = {snr:.2f} dB")

# Lưu kết quả SNR để checkwork
snr_path = os.path.join(LAB_DIR, 'snr_result.txt')
with open(snr_path, 'w') as f:
    f.write("=== SNR So Sanh ===\n")
    for pol, snr in snr_results.items():
        f.write(f"{pol}_snr={snr:.4f}\n")
    # dòng để checkwork CONTAINS khớp
    f.write(f"adaptive_snr={snr_results['adaptive']:.4f}\n")

# Lưu kết quả dung lượng để checkwork
cap_path = os.path.join(LAB_DIR, 'capacity_result.txt')
with open(cap_path, 'w') as f:
    f.write("=== Capacity So Sanh ===\n")
    for pol, cap in cap_results.items():
        f.write(f"{pol}_capacity_bits={cap}\n")
        f.write(f"{pol}_capacity_bytes={cap//8}\n")
    # dòng để checkwork CONTAINS khớp
    f.write(f"adaptive_capacity={cap_results['adaptive']//8}\n")

print(f"\n[OK] SNR lưu vào      : {snr_path}")
print(f"[OK] Dung lượng lưu vào: {cap_path}")

# Nhận xét
print("\n=== Nhan xet ===")
if snr_results['adaptive'] > snr_results['fixed2']:
    print("[+] Adaptive LSB co SNR cao hon fixed-2bit -> it gay nhieu hon")
else:
    print("[-] Kiem tra lai thuat toan embed")
if cap_results['adaptive'] > cap_results['fixed1']:
    print("[+] Adaptive LSB co dung luong lon hon fixed-1bit -> hieu qua hon")
