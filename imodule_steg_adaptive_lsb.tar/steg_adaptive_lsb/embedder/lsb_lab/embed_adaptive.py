#!/usr/bin/env python3
"""
Bước 3: Nhúng thông điệp vào file WAV bằng Adaptive LSB.
Chạy: python3 embed_adaptive.py
"""
import wave, struct, os

LAB_DIR = '/home/ubuntu/lsb_lab'


def get_lsb_bits(amplitude):
    a = abs(amplitude)
    if a < 8000:
        return 1
    elif a < 20000:
        return 2
    else:
        return 3


def embed_adaptive(wav_in, wav_out, message):
    sentinel = message + '||END||'
    all_bits = ''.join(f'{b:08b}' for b in sentinel.encode())

    with wave.open(wav_in, 'r') as f:
        params = f.getparams()
        frames = f.readframes(f.getnframes())
    samples = list(struct.unpack(f'<{len(frames)//2}h', frames))

    bit_ptr = 0
    for i, s in enumerate(samples):
        if bit_ptr >= len(all_bits):
            break
        n_bits = get_lsb_bits(s)
        chunk  = all_bits[bit_ptr : bit_ptr + n_bits]
        chunk  = chunk.ljust(n_bits, '0')
        mask   = (1 << n_bits) - 1
        samples[i] = (s & ~mask) | int(chunk, 2)
        bit_ptr += n_bits

    success = bit_ptr >= len(all_bits)
    if not success:
        print(f"[CANH BAO] Chi nhung duoc {bit_ptr}/{len(all_bits)} bits!")
    else:
        print(f"[OK] Nhung thanh cong {len(all_bits)} bits ({len(sentinel)} ky tu).")

    new_frames = struct.pack(f'<{len(samples)}h', *samples)
    with wave.open(wav_out, 'w') as fout:
        fout.setparams(params)
        fout.writeframes(new_frames)

    return success, len(all_bits), bit_ptr


# ---- Chạy nhúng ----
MESSAGE   = "AdaptiveLSBTest"
WAV_IN    = os.path.join(LAB_DIR, 'cover_audio.wav')
WAV_OUT   = os.path.join(LAB_DIR, 'stego_adaptive.wav')

success, total_bits, embedded_bits = embed_adaptive(WAV_IN, WAV_OUT, MESSAGE)

# Lưu kết quả để checkwork
result_path = os.path.join(LAB_DIR, 'embed_result.txt')
with open(result_path, 'w') as f:
    f.write(f"embed_success={'YES' if success else 'NO'}\n")
    f.write(f"total_bits={total_bits}\n")
    f.write(f"embedded_bits={embedded_bits}\n")
    f.write(f"message={MESSAGE}\n")
    f.write(f"output_file=stego_adaptive.wav\n")

print(f"[OK] Kết quả đã lưu vào: {result_path}")
print(f"[OK] File stego: {WAV_OUT}")
