#!/usr/bin/env python3
"""
Step 3: embed a message into a WAV file using Adaptive LSB.

Student task:
  Complete the TODO block inside embed_adaptive().
"""
import os
import shutil
import struct
import wave

from adaptive_policy import get_lsb_bits

LAB_DIR = "/home/ubuntu/lsb_lab"
RESULT_DIR = "/home/ubuntu/.local/result"
MESSAGE = "AdaptiveLSBTest"


def save_result(name, content):
    os.makedirs(RESULT_DIR, exist_ok=True)
    lab_path = os.path.join(LAB_DIR, name)
    result_path = os.path.join(RESULT_DIR, name)
    with open(lab_path, "w") as f:
        f.write(content)
    shutil.copyfile(lab_path, result_path)
    return lab_path


def embed_adaptive(wav_in, wav_out, message):
    sentinel = message + "||END||"
    all_bits = "".join(f"{b:08b}" for b in sentinel.encode())

    with wave.open(wav_in, "r") as f:
        params = f.getparams()
        frames = f.readframes(f.getnframes())

    samples = list(struct.unpack(f"<{len(frames)//2}h", frames))

    bit_ptr = 0
    for i, s in enumerate(samples):
        if bit_ptr >= len(all_bits):
            break

        n_bits = get_lsb_bits(s)
        chunk = all_bits[bit_ptr: bit_ptr + n_bits].ljust(n_bits, "0")

        # TODO: Student completes these 2 lines.
        # Hint:
        #   mask = (1 << n_bits) - 1
        #   new_sample = clear the n LSBs of s, then OR with int(chunk, 2)
        raise NotImplementedError("Complete the Adaptive LSB embedding TODO")

        samples[i] = new_sample
        bit_ptr += n_bits

    success = bit_ptr >= len(all_bits)
    new_frames = struct.pack(f"<{len(samples)}h", *samples)
    with wave.open(wav_out, "w") as fout:
        fout.setparams(params)
        fout.writeframes(new_frames)

    return success, len(all_bits), bit_ptr


wav_in = os.path.join(LAB_DIR, "cover_audio.wav")
wav_out = os.path.join(LAB_DIR, "stego_adaptive.wav")

try:
    success, total_bits, embedded_bits = embed_adaptive(wav_in, wav_out, MESSAGE)
    lines = [
        f"embed_success={'YES' if success else 'NO'}",
        f"total_bits={total_bits}",
        f"embedded_bits={embedded_bits}",
        f"message={MESSAGE}",
        "output_file=stego_adaptive.wav",
    ]
    print(f"[OK] embedded {embedded_bits}/{total_bits} bits")
except Exception as exc:
    lines = [
        "embed_success=NO",
        f"embed_error={type(exc).__name__}: {exc}",
        f"message={MESSAGE}",
    ]
    print(f"[ERROR] {exc}")

path = save_result("embed_result.txt", "\n".join(lines) + "\n")
print(f"[OK] result saved to: {path}")
