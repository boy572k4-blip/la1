#!/usr/bin/env python3
"""
Step 4: extract a message from a WAV file produced by Adaptive LSB.

Student task:
  Complete the TODO block inside extract_adaptive().
"""
import os
import shutil
import struct
import wave

from adaptive_policy import get_lsb_bits

LAB_DIR = "/home/ubuntu/lsb_lab"
RESULT_DIR = "/home/ubuntu/.local/result"


def save_result(name, content):
    os.makedirs(RESULT_DIR, exist_ok=True)
    lab_path = os.path.join(LAB_DIR, name)
    result_path = os.path.join(RESULT_DIR, name)
    with open(lab_path, "w") as f:
        f.write(content)
    shutil.copyfile(lab_path, result_path)
    return lab_path


def extract_adaptive(wav_stego, wav_cover):
    with wave.open(wav_stego, "r") as f:
        frames_s = f.readframes(f.getnframes())
    with wave.open(wav_cover, "r") as f:
        frames_c = f.readframes(f.getnframes())

    stego = struct.unpack(f"<{len(frames_s)//2}h", frames_s)
    cover = struct.unpack(f"<{len(frames_c)//2}h", frames_c)

    bits = ""
    msg = ""
    for s_val, c_val in zip(stego, cover):
        n_bits = get_lsb_bits(c_val)

        # TODO: Student completes these 2 lines.
        # Hint:
        #   mask = (1 << n_bits) - 1
        #   chunk = binary string of the n LSBs in s_val, padded to n_bits
        raise NotImplementedError("Complete the Adaptive LSB extraction TODO")

        bits += chunk
        while len(bits) >= 8:
            msg += chr(int(bits[:8], 2))
            bits = bits[8:]
            if msg.endswith("||END||"):
                return msg[:-7]

    return None


wav_stego = os.path.join(LAB_DIR, "stego_adaptive.wav")
wav_cover = os.path.join(LAB_DIR, "cover_audio.wav")

try:
    decoded = extract_adaptive(wav_stego, wav_cover)
    if decoded:
        lines = [
            "extract_success=YES",
            "EXTRACT_SUCCESS_YES",
            f"decoded_message={decoded}",
            decoded,
        ]
        print(f"[OK] decoded message: {decoded}")
    else:
        lines = [
            "extract_success=NO",
            "EXTRACT_SUCCESS_NO",
            "decoded_message=NOT_FOUND",
        ]
        print("[WARNING] message not found")
except Exception as exc:
    lines = [
        "extract_success=NO",
        "EXTRACT_SUCCESS_NO",
        f"extract_error={type(exc).__name__}: {exc}",
    ]
    print(f"[ERROR] {exc}")

path = save_result("extract_result.txt", "\n".join(lines) + "\n")
print(f"[OK] result saved to: {path}")
