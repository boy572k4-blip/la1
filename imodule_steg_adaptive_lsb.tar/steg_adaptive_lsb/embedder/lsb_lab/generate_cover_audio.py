#!/usr/bin/env python3
"""Tạo file cover_audio.wav cho bài lab Adaptive LSB Steganography"""
import wave, struct, math, random, os

LAB_DIR = '/home/ubuntu/lsb_lab'
os.makedirs(LAB_DIR, exist_ok=True)

SAMPLE_RATE = 44100
DURATION    = 5        # giây
NUM_SAMPLES = SAMPLE_RATE * DURATION

random.seed(2024)
samples = []
for i in range(NUM_SAMPLES):
    t = i / SAMPLE_RATE
    # Kết hợp nhiều tần số để biên độ thay đổi phong phú
    s  = 20000 * math.sin(2 * math.pi * 440  * t)   # nốt A4
    s += 15000 * math.sin(2 * math.pi * 880  * t)   # octave
    s += 10000 * math.sin(2 * math.pi * 1320 * t)   # harmonic
    s += random.randint(-3000, 3000)                 # noise
    s  = max(-32767, min(32767, int(s)))
    samples.append(s)

out = os.path.join(LAB_DIR, 'cover_audio.wav')
with wave.open(out, 'w') as f:
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(SAMPLE_RATE)
    f.writeframes(struct.pack(f'<{NUM_SAMPLES}h', *samples))

print(f"[OK] cover_audio.wav: {NUM_SAMPLES} mẫu, {DURATION}s -> {out}")
