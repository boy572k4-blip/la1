#!/usr/bin/env python3
"""
Tạo file stego_fixed1.wav và stego_fixed2.wav để so sánh với adaptive.
Chạy trước compare_methods.py.
"""
import wave, struct, os

LAB_DIR = '/home/ubuntu/lsb_lab'


def embed_fixed(wav_in, wav_out, message, n_bits):
    sentinel = message + '||END||'
    all_bits = ''.join(f'{b:08b}' for b in sentinel.encode())
    with wave.open(wav_in, 'r') as f:
        params = f.getparams()
        frames = f.readframes(f.getnframes())
    samples = list(struct.unpack(f'<{len(frames)//2}h', frames))
    mask = (1 << n_bits) - 1
    bit_ptr = 0
    for i, s in enumerate(samples):
        if bit_ptr >= len(all_bits):
            break
        chunk = all_bits[bit_ptr:bit_ptr + n_bits].ljust(n_bits, '0')
        samples[i] = (s & ~mask) | int(chunk, 2)
        bit_ptr += n_bits
    new_frames = struct.pack(f'<{len(samples)}h', *samples)
    with wave.open(wav_out, 'w') as fout:
        fout.setparams(params)
        fout.writeframes(new_frames)
    print(f"[OK] {wav_out} (fixed {n_bits}-bit LSB)")


WAV_IN  = os.path.join(LAB_DIR, 'cover_audio.wav')
MSG     = "AdaptiveLSBTest"

embed_fixed(WAV_IN, os.path.join(LAB_DIR, 'stego_fixed1.wav'), MSG, 1)
embed_fixed(WAV_IN, os.path.join(LAB_DIR, 'stego_fixed2.wav'), MSG, 2)
print("[OK] Đã tạo xong stego_fixed1.wav và stego_fixed2.wav")
