#!/bin/bash
service ssh start 2>/dev/null

mkdir -p /home/ubuntu/.local/bin
mkdir -p /home/ubuntu/.local/result
mkdir -p /home/ubuntu/.local/zip
mkdir -p /home/ubuntu/.local/config

echo "steg_adaptive_lsb"       > /home/ubuntu/.local/.labname
echo "steg_adaptive_lsb_seed"  > /home/ubuntu/.local/.seed

chown -R ubuntu:ubuntu /home/ubuntu/.local

mkdir -p /var/labtainer
touch /var/labtainer/did_param

mkdir -p /home/ubuntu/lsb_lab
chown -R ubuntu:ubuntu /home/ubuntu/lsb_lab
if [ ! -f /home/ubuntu/lsb_lab/cover_audio.wav ]; then
    cd /home/ubuntu/lsb_lab
    sudo -u ubuntu python3 generate_cover_audio.py 2>/dev/null
fi

tail -f /dev/null
