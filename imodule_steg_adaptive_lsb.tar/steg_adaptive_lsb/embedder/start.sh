#!/bin/bash
service ssh start 2>/dev/null

# Seed và thông tin Labtainer
mkdir -p /home/ubuntu/.local
echo "steg_adaptive_lsb_seed"  > /home/ubuntu/.local/.seed
echo "student@labtainer.local"  > /home/ubuntu/.local/.email
echo "steg_adaptive_lsb"        > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

# Cần cho Student.py (checkwork)
mkdir -p /var/labtainer
touch /var/labtainer/did_param

# Tạo cover_audio.wav nếu chưa có
mkdir -p /home/ubuntu/lsb_lab
chown -R ubuntu:ubuntu /home/ubuntu/lsb_lab
if [ ! -f /home/ubuntu/lsb_lab/cover_audio.wav ]; then
    python3 /home/ubuntu/lsb_lab/generate_cover_audio.py 2>/dev/null
    chown ubuntu:ubuntu /home/ubuntu/lsb_lab/cover_audio.wav 2>/dev/null
fi

tail -f /dev/null
