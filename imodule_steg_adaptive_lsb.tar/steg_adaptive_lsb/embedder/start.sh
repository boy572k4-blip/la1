#!/bin/bash
service ssh start 2>/dev/null

mkdir -p /var/labtainer
echo "steg_adaptive_lsb_seed" > /var/labtainer/seed

mkdir -p /home/ubuntu/.local
echo "steg_adaptive_lsb_seed"   > /home/ubuntu/.local/.seed
echo "student@labtainer.local"  > /home/ubuntu/.local/.email
echo "steg_adaptive_lsb"        > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

touch /var/labtainer/did_param

mkdir -p /home/ubuntu/lsb_lab
chown -R ubuntu:ubuntu /home/ubuntu/lsb_lab
ln -sfn /home/ubuntu/lsb_lab /root/lsb_lab
grep -qxF 'cd /home/ubuntu/lsb_lab 2>/dev/null || true' /root/.bashrc 2>/dev/null || \
    echo 'cd /home/ubuntu/lsb_lab 2>/dev/null || true' >> /root/.bashrc

if [ ! -f /home/ubuntu/lsb_lab/cover_audio.wav ]; then
    python3 /home/ubuntu/lsb_lab/generate_cover_audio.py 2>/dev/null
    chown ubuntu:ubuntu /home/ubuntu/lsb_lab/cover_audio.wav 2>/dev/null
fi

tail -f /dev/null
