#!/bin/bash
service ssh start 2>/dev/null

# Labtainer metadata (Labtainer sẽ tự inject .email và .labname qua param)
mkdir -p /home/ubuntu/.local/bin
mkdir -p /home/ubuntu/.local/result
mkdir -p /home/ubuntu/.local/zip
mkdir -p /home/ubuntu/.local/config

# Fallback nếu chưa được inject
[ ! -f /home/ubuntu/.local/.labname ] && echo "steg_adaptive_lsb" > /home/ubuntu/.local/.labname
[ ! -f /home/ubuntu/.local/.seed ]    && echo "steg_adaptive_lsb_seed" > /home/ubuntu/.local/.seed

chown -R ubuntu:ubuntu /home/ubuntu/.local

# Cần cho Student.py (checkwork timestamp)
mkdir -p /var/labtainer
touch /var/labtainer/did_param

# Tạo cover_audio.wav nếu chưa có
mkdir -p /home/ubuntu/lsb_lab
chown -R ubuntu:ubuntu /home/ubuntu/lsb_lab
if [ ! -f /home/ubuntu/lsb_lab/cover_audio.wav ]; then
    cd /home/ubuntu/lsb_lab
    sudo -u ubuntu python3 generate_cover_audio.py 2>/dev/null || \
    python3 /home/ubuntu/lsb_lab/generate_cover_audio.py 2>/dev/null
fi

tail -f /dev/null
