#!/bin/bash
homedir=$1
destdir=$2
cd $homedir/$destdir
