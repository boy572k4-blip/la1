#!/bin/bash
set +e

MYHOME="$1"
DEST="$2"
LABROOT="$MYHOME/$DEST"

mkdir -p "$LABROOT/embedder/.local/result"
mkdir -p "$LABROOT/analyzer/.local/result"

for f in amplitude_result.txt policy_result.txt embed_result.txt extract_result.txt; do
    if [ -f "$LABROOT/embedder/lsb_lab/$f" ]; then
        cp "$LABROOT/embedder/lsb_lab/$f" "$LABROOT/embedder/.local/result/$f"
    fi
done

for f in snr_result.txt capacity_result.txt; do
    if [ -f "$LABROOT/analyzer/lsb_lab/$f" ]; then
        cp "$LABROOT/analyzer/lsb_lab/$f" "$LABROOT/analyzer/.local/result/$f"
    fi
done

exit 0
